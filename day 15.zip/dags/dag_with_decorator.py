from airflow.decorators import dag
from airflow.operators.empty import EmptyOperator


#3. Cara dekorator
#dengan menggunakan sebuah function, mirip dengan with statement di dalamnya sudah masuk ke operator tsb
#sehingga tidak perlu memasukkan parameter ke variabael

@dag() #isinya sama persis dengan with dag / cara 2
#jika tidak assign nama dag pada dekorator, maka airflow akan membuat nama function sebagai nama dagnya
#jika diassign misal dag_id = "dag_a" airfflow akan mengambail dag_a sebagai nama dagnya
def dag_with_decorator():
    task_1 = EmptyOperator(
        task_id = "task_ke_1"
    )

    task_1

dag_with_decorator()
#harus dipanggil functionnya
