def splitted_python(param1, **kwargs):
   print("ini adalah operator python dengan import")
   print(param1)
   print(kwargs['param2'])

