SELECT * FROM dibimbing.users

